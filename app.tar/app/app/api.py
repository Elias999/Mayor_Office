from . import models
from . import serializers
from rest_framework import viewsets, permissions


class complainViewSet(viewsets.ModelViewSet):
    """ViewSet for the complain class"""

    queryset = models.complain.objects.all()
    serializer_class = serializers.complainSerializer
    permission_classes = [permissions.IsAuthenticated]


class infrastructureViewSet(viewsets.ModelViewSet):
    """ViewSet for the infrastructure class"""

    queryset = models.infrastructure.objects.all()
    serializer_class = serializers.infrastructureSerializer
    permission_classes = [permissions.IsAuthenticated]


class crewViewSet(viewsets.ModelViewSet):
    """ViewSet for the crew class"""

    queryset = models.crew.objects.all()
    serializer_class = serializers.crewSerializer
    permission_classes = [permissions.IsAuthenticated]


