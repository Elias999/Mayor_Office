from django.urls import path, include
from rest_framework import routers

from . import api
from . import views

router = routers.DefaultRouter()
router.register(r'complain', api.complainViewSet)
router.register(r'infrastructure', api.infrastructureViewSet)
router.register(r'crew', api.crewViewSet)


urlpatterns = (
    # urls for Django Rest Framework API
    path('api/v1/', include(router.urls)),
)

urlpatterns += (
    # urls for complain
    path('app/complain/', views.complainListView.as_view(), name='app_complain_list'),
    path('app/complain/create/', views.complainCreateView.as_view(), name='app_complain_create'),
    path('app/complain/detail/<slug:slug>/', views.complainDetailView.as_view(), name='app_complain_detail'),
    path('app/complain/update/<slug:slug>/', views.complainUpdateView.as_view(), name='app_complain_update'),
)

urlpatterns += (
    # urls for infrastructure
    path('app/infrastructure/', views.infrastructureListView.as_view(), name='app_infrastructure_list'),
    path('app/infrastructure/create/', views.infrastructureCreateView.as_view(), name='app_infrastructure_create'),
    path('app/infrastructure/detail/<int:pk>/', views.infrastructureDetailView.as_view(), name='app_infrastructure_detail'),
    path('app/infrastructure/update/<int:pk>/', views.infrastructureUpdateView.as_view(), name='app_infrastructure_update'),
)

urlpatterns += (
    # urls for crew
    path('app/crew/', views.crewListView.as_view(), name='app_crew_list'),
    path('app/crew/create/', views.crewCreateView.as_view(), name='app_crew_create'),
    path('app/crew/detail/<int:pk>/', views.crewDetailView.as_view(), name='app_crew_detail'),
    path('app/crew/update/<int:pk>/', views.crewUpdateView.as_view(), name='app_crew_update'),
)

