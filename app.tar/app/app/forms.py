from django import forms
from .models import complain, infrastructure, crew


class complainForm(forms.ModelForm):
    class Meta:
        model = complain
        fields = ['made_afm', 'resolved', 'notes', 'resolve_date']


class infrastructureForm(forms.ModelForm):
    class Meta:
        model = infrastructure
        fields = ['google_location', 'type']


class crewForm(forms.ModelForm):
    class Meta:
        model = crew
        fields = ['name', 'working_hours', 'crew_members']


