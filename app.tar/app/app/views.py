from django.views.generic import DetailView, ListView, UpdateView, CreateView
from .models import complain, infrastructure, crew
from .forms import complainForm, infrastructureForm, crewForm


class complainListView(ListView):
    model = complain


class complainCreateView(CreateView):
    model = complain
    form_class = complainForm


class complainDetailView(DetailView):
    model = complain


class complainUpdateView(UpdateView):
    model = complain
    form_class = complainForm


class infrastructureListView(ListView):
    model = infrastructure


class infrastructureCreateView(CreateView):
    model = infrastructure
    form_class = infrastructureForm


class infrastructureDetailView(DetailView):
    model = infrastructure


class infrastructureUpdateView(UpdateView):
    model = infrastructure
    form_class = infrastructureForm


class crewListView(ListView):
    model = crew


class crewCreateView(CreateView):
    model = crew
    form_class = crewForm


class crewDetailView(DetailView):
    model = crew


class crewUpdateView(UpdateView):
    model = crew
    form_class = crewForm

