from . import models

from rest_framework import serializers


class complainSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.complain
        fields = (
            'slug', 
            'made_afm', 
            'created', 
            'resolved', 
            'infrastructure_id', 
            'notes', 
            'resolve_date', 
        )


class infrastructureSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.infrastructure
        fields = (
            'pk', 
            'UUID', 
            'created', 
            'last_updated', 
            'google_location', 
            'type', 
        )


class crewSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.crew
        fields = (
            'pk', 
            'name', 
            'UUID', 
            'created', 
            'last_updated', 
            'working_hours', 
            'crew_members', 
            'complains_id', 
        )


