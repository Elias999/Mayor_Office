import unittest
from django.urls import reverse
from django.test import Client
from .models import complain, infrastructure, crew
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType


def create_django_contrib_auth_models_user(**kwargs):
    defaults = {}
    defaults["username"] = "username"
    defaults["email"] = "username@tempurl.com"
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_django_contrib_auth_models_group(**kwargs):
    defaults = {}
    defaults["name"] = "group"
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_django_contrib_contenttypes_models_contenttype(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_complain(**kwargs):
    defaults = {}
    defaults["made_afm"] = "made_afm"
    defaults["resolved"] = "resolved"
    defaults["notes"] = "notes"
    defaults["resolve_date"] = "resolve_date"
    defaults.update(**kwargs)
    return complain.objects.create(**defaults)


def create_infrastructure(**kwargs):
    defaults = {}
    defaults["google_location"] = "google_location"
    defaults["type"] = "type"
    defaults.update(**kwargs)
    return infrastructure.objects.create(**defaults)


def create_crew(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults["working_hours"] = "working_hours"
    defaults["crew_members"] = "crew_members"
    defaults.update(**kwargs)
    return crew.objects.create(**defaults)


class complainViewTest(unittest.TestCase):
    '''
    Tests for complain
    '''
    def setUp(self):
        self.client = Client()

    def test_list_complain(self):
        url = reverse('app_complain_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_complain(self):
        url = reverse('app_complain_create')
        data = {
            "made_afm": "made_afm",
            "resolved": "resolved",
            "notes": "notes",
            "resolve_date": "resolve_date",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_complain(self):
        complain = create_complain()
        url = reverse('app_complain_detail', args=[complain.slug,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_complain(self):
        complain = create_complain()
        data = {
            "made_afm": "made_afm",
            "resolved": "resolved",
            "notes": "notes",
            "resolve_date": "resolve_date",
        }
        url = reverse('app_complain_update', args=[complain.slug,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class infrastructureViewTest(unittest.TestCase):
    '''
    Tests for infrastructure
    '''
    def setUp(self):
        self.client = Client()

    def test_list_infrastructure(self):
        url = reverse('app_infrastructure_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_infrastructure(self):
        url = reverse('app_infrastructure_create')
        data = {
            "google_location": "google_location",
            "type": "type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_infrastructure(self):
        infrastructure = create_infrastructure()
        url = reverse('app_infrastructure_detail', args=[infrastructure.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_infrastructure(self):
        infrastructure = create_infrastructure()
        data = {
            "google_location": "google_location",
            "type": "type",
        }
        url = reverse('app_infrastructure_update', args=[infrastructure.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class crewViewTest(unittest.TestCase):
    '''
    Tests for crew
    '''
    def setUp(self):
        self.client = Client()

    def test_list_crew(self):
        url = reverse('app_crew_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_crew(self):
        url = reverse('app_crew_create')
        data = {
            "name": "name",
            "working_hours": "working_hours",
            "crew_members": "crew_members",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_crew(self):
        crew = create_crew()
        url = reverse('app_crew_detail', args=[crew.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_crew(self):
        crew = create_crew()
        data = {
            "name": "name",
            "working_hours": "working_hours",
            "crew_members": "crew_members",
        }
        url = reverse('app_crew_update', args=[crew.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


